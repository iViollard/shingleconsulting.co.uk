---
title: SUBSCRIBE TO STAY IN THE LOOP
hidemenu: true
testimonials:
  - avatar: face1.jpg
    quote: Good design at the front-end suggests that everything is in order at the back-end, whether or not that is the case.
    author: Dmitry Fadeyev
  - avatar: face2.jpg
    quote: It’s not about knowing all the gimmicks and photo tricks. If you haven’t got the eye, no program will give it to you.
    author: David Carson
  - avatar: face3.jpg
    quote: There’s a point when you’re done simplifying. Otherwise, things get really complicated.
    author: Frank Chimero     
  - avatar: face4.jpg
    quote: Designing for clients that don’t appreciate the value of design is like buying new tires for a rental car.
    author: Joel Fisher  
  - avatar: face5.jpg
    quote: Every picture owes more to other pictures painted before than it owes to nature.
    author: E.H. Gombrich  
---
### Testimonials {.sr-only}
